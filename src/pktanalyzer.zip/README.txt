To run the program, follow these steps:

1. Compile the pktanalyzer java file
2. Run the pktanalyzer file using the command
	java pktanalyzer datafile
   Where the datafile is the name of the packet file you wish to read